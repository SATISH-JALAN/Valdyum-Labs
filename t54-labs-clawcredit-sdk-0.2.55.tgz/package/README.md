# ClawCredit SDK for Open Claw

ClawCredit provides a credit line and payment workflow for Open Claw Agents using t54's Trustline and the x402 protocol.
This SDK lets an agent register for credit, submit context for underwriting, and pay
merchants with this credit service. Trustline's risk engine evaluates the
agent's integration depth, richness of risk signals, and credit history
(including on-time repayments and other records) to issue updated credit
limits daily or dynamically.

## About Open Claw

Open Claw is an open-source agent framework that runs your personal AI assistant
across platforms, with a gateway, skills, and channel integrations. It is
designed to let agents run locally or remotely, with a configurable workspace
and a modular “skills” system you can extend.  
Repository: https://github.com/openclaw/openclaw

## Quick Start

Install the SDK:

```bash
npm install @t54-labs/clawcredit-sdk
```

Configure token via CLI (recommended for humans, not agents):

```bash
clawcredit configure --token YOUR_API_TOKEN --service-url https://api.claw.credit
```

Initialize and register:

```javascript
const { ClawCredit } = require('@t54-labs/clawcredit-sdk');

const credit = new ClawCredit({
  agentName: "MyOpenClawAgent"
});

await credit.register({
  inviteCode: "YOUR_INVITE_CODE",
  runtimeEnv: "node-v22",
  model: "gpt-5.2" // Optional
});
```

## Enable Reasoning Trace (Required For Stable Payments)

Trace helps the risk engine evaluate why a payment is needed. In practice, you should treat traced execution as a required precondition for stable `credit.pay()` approvals.

```javascript
const OpenAI = require('openai');
const { wrapOpenAI, withTrace } = require('@t54-labs/clawcredit-sdk');

const openai = wrapOpenAI(new OpenAI({ apiKey: process.env.OPENAI_API_KEY }));

await withTrace(async () => {
  await openai.chat.completions.create({
    messages: [{ role: "user", content: "Fetch the latest BTC price." }],
    model: "gpt-5.2"
  });
});
```

### Payment Preflight (Before `credit.pay()`)

Before each payment call:

1. Make a recent LLM call with a `wrapOpenAI(...)` client.
2. Keep the LLM call and `credit.pay()` in the same logical run (prefer one `withTrace(...)` block).
3. Pass the original merchant HTTP request in `request_body.http`.
4. For retries of the same logical payment, reuse the same `idempotencyKey`.
5. If trace capture failed or is stale, run a fresh traced LLM step before paying.

## Pay a Merchant

```javascript
const result = await credit.pay({
  transaction: {
    recipient: "merchant_address_or_id",
    amount: 1.5, // Human-readable USD amount
    chain: "BASE",
    asset: "USDC"
  },
  request_body: {
    service_name: "PremiumSearch",
    params: { query: "BTC price" }
  },
  // Recommended for highest approval stability:
  // context: { reasoning_process: "I need real-time data to answer the user." }
});

console.log(result);
```

`transaction.amount` is interpreted as a human-readable USD amount by default.
If you pass atomic units from an x402 quote (for example `10000` for USDC),
set `transaction.amount_unit: "atomic"` or convert before calling `pay()`.

```javascript
await credit.pay({
  transaction: {
    recipient: "merchant_address_or_id",
    amount: 10000,        // Atomic units
    amount_unit: "atomic",
    chain: "BASE",
    asset: "USDC"
  },
  request_body
});
```

You can also build the payment from a quote directly:

```javascript
await credit.payFromX402Quote({
  quote, // 402 payload or selected requirement with maxAmountRequired/amount
  transaction: {
    recipient: "merchant_address_or_id",
    chain: "BASE",
    asset: "USDC"
  },
  request_body
});
```

## How an Open Claw Agent Learns This Skill

Open Claw agents can be taught via a skill guide. Provide the agent with the
`SKILL.md` in this package and instruct it to:

1. Install the SDK: `npm install @t54-labs/clawcredit-sdk`
2. Register using `credit.register()` with an invite code.
3. Wrap the OpenAI client with `wrapOpenAI()` and run payment flows under `withTrace()`.
4. Use `credit.pay()` with `transaction` and `request_body` after trace preflight checks.

The `SKILL.md` file in this package contains a step-by-step guide tailored for
agent use. You can host it and prompt agents to read and follow it.

## Session Data Compression

**New in v0.1.8**: The SDK automatically compresses session transcript data before transmission, reducing payload size by ~85%.

The compression process:
- **Removes encrypted thinking blocks** - saves ~60-70% of space
- **Strips usage/cost statistics** - not needed for credit assessment
- **Simplifies tool outputs** - keeps only status, not full content
- **Eliminates redundant metadata** - reduces overhead

All compressed data includes an **SDK signature** certifying the compression was intentional and performed by the official SDK:

```json
{
  "sdk_signature": {
    "sdk_name": "@t54-labs/clawcredit-sdk",
    "sdk_version": "0.1.8",
    "compression_applied": true,
    "compression_timestamp": "2026-02-03T07:16:15.022Z",
    "fields_removed": [
      "encrypted_thinking_blocks",
      "usage_statistics",
      "cost_information",
      "detailed_tool_outputs",
      "redundant_metadata"
    ],
    "compression_stats": {
      "totalOriginalSize": 573883,
      "totalCompressedSize": 88616,
      "compressionRatio": "84.56%"
    }
  }
}
```

This optimization significantly reduces network transfer time and API costs while preserving all information needed for credit risk assessment.

## Exports

```javascript
const {
  ClawCredit,
  wrapOpenAI,
  withTrace
} = require('@t54-labs/clawcredit-sdk');
```

